import {
  useFetcher,
  useOutletContext
} from "/build/_shared/chunk-BC5VDABJ.js";
import {
  require_jsx_dev_runtime
} from "/build/_shared/chunk-XGOTYLZ5.js";
import {
  createHotContext
} from "/build/_shared/chunk-MCH5QMAS.js";
import {
  require_react
} from "/build/_shared/chunk-7M6SC7J5.js";
import {
  __toESM
} from "/build/_shared/chunk-PNG5AS42.js";

// app/components/BoxRecipe.tsx
var import_react3 = __toESM(require_react(), 1);

// app/components/RecipeModal.tsx
var import_react = __toESM(require_react(), 1);

// node_modules/react-swipeable/es/index.js
var React = __toESM(require_react());
var LEFT = "Left";
var RIGHT = "Right";
var UP = "Up";
var DOWN = "Down";
var defaultProps = {
  delta: 10,
  preventScrollOnSwipe: false,
  rotationAngle: 0,
  trackMouse: false,
  trackTouch: true,
  swipeDuration: Infinity,
  touchEventOptions: { passive: true }
};
var initialState = {
  first: true,
  initial: [0, 0],
  start: 0,
  swiping: false,
  xy: [0, 0]
};
var mouseMove = "mousemove";
var mouseUp = "mouseup";
var touchEnd = "touchend";
var touchMove = "touchmove";
var touchStart = "touchstart";
function getDirection(absX, absY, deltaX, deltaY) {
  if (absX > absY) {
    if (deltaX > 0) {
      return RIGHT;
    }
    return LEFT;
  } else if (deltaY > 0) {
    return DOWN;
  }
  return UP;
}
function rotateXYByAngle(pos, angle) {
  if (angle === 0)
    return pos;
  const angleInRadians = Math.PI / 180 * angle;
  const x = pos[0] * Math.cos(angleInRadians) + pos[1] * Math.sin(angleInRadians);
  const y = pos[1] * Math.cos(angleInRadians) - pos[0] * Math.sin(angleInRadians);
  return [x, y];
}
function getHandlers(set, handlerProps) {
  const onStart = (event) => {
    const isTouch = "touches" in event;
    if (isTouch && event.touches.length > 1)
      return;
    set((state, props) => {
      if (props.trackMouse && !isTouch) {
        document.addEventListener(mouseMove, onMove);
        document.addEventListener(mouseUp, onUp);
      }
      const { clientX, clientY } = isTouch ? event.touches[0] : event;
      const xy = rotateXYByAngle([clientX, clientY], props.rotationAngle);
      props.onTouchStartOrOnMouseDown && props.onTouchStartOrOnMouseDown({ event });
      return Object.assign(Object.assign(Object.assign({}, state), initialState), { initial: xy.slice(), xy, start: event.timeStamp || 0 });
    });
  };
  const onMove = (event) => {
    set((state, props) => {
      const isTouch = "touches" in event;
      if (isTouch && event.touches.length > 1) {
        return state;
      }
      if (event.timeStamp - state.start > props.swipeDuration) {
        return state.swiping ? Object.assign(Object.assign({}, state), { swiping: false }) : state;
      }
      const { clientX, clientY } = isTouch ? event.touches[0] : event;
      const [x, y] = rotateXYByAngle([clientX, clientY], props.rotationAngle);
      const deltaX = x - state.xy[0];
      const deltaY = y - state.xy[1];
      const absX = Math.abs(deltaX);
      const absY = Math.abs(deltaY);
      const time = (event.timeStamp || 0) - state.start;
      const velocity = Math.sqrt(absX * absX + absY * absY) / (time || 1);
      const vxvy = [deltaX / (time || 1), deltaY / (time || 1)];
      const dir = getDirection(absX, absY, deltaX, deltaY);
      const delta = typeof props.delta === "number" ? props.delta : props.delta[dir.toLowerCase()] || defaultProps.delta;
      if (absX < delta && absY < delta && !state.swiping)
        return state;
      const eventData = {
        absX,
        absY,
        deltaX,
        deltaY,
        dir,
        event,
        first: state.first,
        initial: state.initial,
        velocity,
        vxvy
      };
      eventData.first && props.onSwipeStart && props.onSwipeStart(eventData);
      props.onSwiping && props.onSwiping(eventData);
      let cancelablePageSwipe = false;
      if (props.onSwiping || props.onSwiped || props[`onSwiped${dir}`]) {
        cancelablePageSwipe = true;
      }
      if (cancelablePageSwipe && props.preventScrollOnSwipe && props.trackTouch && event.cancelable) {
        event.preventDefault();
      }
      return Object.assign(Object.assign({}, state), {
        // first is now always false
        first: false,
        eventData,
        swiping: true
      });
    });
  };
  const onEnd = (event) => {
    set((state, props) => {
      let eventData;
      if (state.swiping && state.eventData) {
        if (event.timeStamp - state.start < props.swipeDuration) {
          eventData = Object.assign(Object.assign({}, state.eventData), { event });
          props.onSwiped && props.onSwiped(eventData);
          const onSwipedDir = props[`onSwiped${eventData.dir}`];
          onSwipedDir && onSwipedDir(eventData);
        }
      } else {
        props.onTap && props.onTap({ event });
      }
      props.onTouchEndOrOnMouseUp && props.onTouchEndOrOnMouseUp({ event });
      return Object.assign(Object.assign(Object.assign({}, state), initialState), { eventData });
    });
  };
  const cleanUpMouse = () => {
    document.removeEventListener(mouseMove, onMove);
    document.removeEventListener(mouseUp, onUp);
  };
  const onUp = (e) => {
    cleanUpMouse();
    onEnd(e);
  };
  const attachTouch = (el, props) => {
    let cleanup = () => {
    };
    if (el && el.addEventListener) {
      const baseOptions = Object.assign(Object.assign({}, defaultProps.touchEventOptions), props.touchEventOptions);
      const tls = [
        [touchStart, onStart, baseOptions],
        // preventScrollOnSwipe option supersedes touchEventOptions.passive
        [
          touchMove,
          onMove,
          Object.assign(Object.assign({}, baseOptions), props.preventScrollOnSwipe ? { passive: false } : {})
        ],
        [touchEnd, onEnd, baseOptions]
      ];
      tls.forEach(([e, h, o]) => el.addEventListener(e, h, o));
      cleanup = () => tls.forEach(([e, h]) => el.removeEventListener(e, h));
    }
    return cleanup;
  };
  const onRef = (el) => {
    if (el === null)
      return;
    set((state, props) => {
      if (state.el === el)
        return state;
      const addState = {};
      if (state.el && state.el !== el && state.cleanUpTouch) {
        state.cleanUpTouch();
        addState.cleanUpTouch = void 0;
      }
      if (props.trackTouch && el) {
        addState.cleanUpTouch = attachTouch(el, props);
      }
      return Object.assign(Object.assign(Object.assign({}, state), { el }), addState);
    });
  };
  const output = {
    ref: onRef
  };
  if (handlerProps.trackMouse) {
    output.onMouseDown = onStart;
  }
  return [output, attachTouch];
}
function updateTransientState(state, props, previousProps, attachTouch) {
  if (!props.trackTouch || !state.el) {
    if (state.cleanUpTouch) {
      state.cleanUpTouch();
    }
    return Object.assign(Object.assign({}, state), { cleanUpTouch: void 0 });
  }
  if (!state.cleanUpTouch) {
    return Object.assign(Object.assign({}, state), { cleanUpTouch: attachTouch(state.el, props) });
  }
  if (props.preventScrollOnSwipe !== previousProps.preventScrollOnSwipe || props.touchEventOptions.passive !== previousProps.touchEventOptions.passive) {
    state.cleanUpTouch();
    return Object.assign(Object.assign({}, state), { cleanUpTouch: attachTouch(state.el, props) });
  }
  return state;
}
function useSwipeable(options) {
  const { trackMouse } = options;
  const transientState = React.useRef(Object.assign({}, initialState));
  const transientProps = React.useRef(Object.assign({}, defaultProps));
  const previousProps = React.useRef(Object.assign({}, transientProps.current));
  previousProps.current = Object.assign({}, transientProps.current);
  transientProps.current = Object.assign(Object.assign({}, defaultProps), options);
  let defaultKey;
  for (defaultKey in defaultProps) {
    if (transientProps.current[defaultKey] === void 0) {
      transientProps.current[defaultKey] = defaultProps[defaultKey];
    }
  }
  const [handlers, attachTouch] = React.useMemo(() => getHandlers((stateSetter) => transientState.current = stateSetter(transientState.current, transientProps.current), { trackMouse }), [trackMouse]);
  transientState.current = updateTransientState(transientState.current, transientProps.current, previousProps.current, attachTouch);
  return handlers;
}

// app/components/RecipeModal.tsx
var import_jsx_dev_runtime = __toESM(require_jsx_dev_runtime(), 1);
if (!window.$RefreshReg$ || !window.$RefreshSig$ || !window.$RefreshRuntime$) {
  console.warn("remix:hmr: React Fast Refresh only works when the Remix compiler is running in development mode.");
} else {
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    window.$RefreshRuntime$.register(type, '"app/components/RecipeModal.tsx"' + id);
  };
  window.$RefreshSig$ = window.$RefreshRuntime$.createSignatureFunctionForTransform;
}
var prevRefreshReg;
var prevRefreshSig;
var _s = $RefreshSig$();
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/components/RecipeModal.tsx"
  );
  import.meta.hot.lastModified = "1743920124794.883";
}
var IngredientsTab = ({
  ingredients
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", { className: "text-xl font-semibold mb-4", children: "Ingr\xE9dients" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 34,
    columnNumber: 9
  }, this),
  ingredients && ingredients.length > 0 ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ul", { className: "space-y-2", children: ingredients.map((item, index) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("li", { className: "flex items-center p-2 border-b border-gray-100 last:border-0", children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-5 h-5 text-rose-500 mr-3 flex-shrink-0", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M5 13l4 4L19 7" }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 38,
      columnNumber: 29
    }, this) }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 37,
      columnNumber: 25
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
      item.quantity && /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "font-medium", children: [
        item.quantity,
        " "
      ] }, void 0, true, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 41,
        columnNumber: 47
      }, this),
      item.unit && /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
        item.unit,
        " de "
      ] }, void 0, true, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 42,
        columnNumber: 43
      }, this),
      item.ingredient.name
    ] }, void 0, true, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 40,
      columnNumber: 25
    }, this)
  ] }, index, true, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 36,
    columnNumber: 51
  }, this)) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 35,
    columnNumber: 50
  }, this) : (
    // eslint-disable-next-line react/no-unescaped-entities
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", { className: "text-gray-500 italic", children: "Aucun ingr\xE9dient n'est sp\xE9cifi\xE9 pour cette recette." }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 48,
      columnNumber: 3
    }, this)
  )
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 33,
  columnNumber: 7
}, this);
_c = IngredientsTab;
var InstructionsTab = ({
  steps,
  completedSteps,
  currentStep,
  onStepClick
}) => {
  const processHtml = (html) => {
    let processedHtml = html.replace(/<i class="ico icon-rotate_cw_2"><\/i>/g, `<svg xmlns="http://www.w3.org/2000/svg" class="inline-block pb-[3px] w-[18px] h-[18px]" viewBox="0 0 512 512"><path d="M48.5 224L40 224c-13.3 0-24-10.7-24-24L16 72c0-9.7 5.8-18.5 14.8-22.2s19.3-1.7 26.2 5.2L98.6 96.6c87.6-86.5 228.7-86.2 315.8 1c87.5 87.5 87.5 229.3 0 316.8s-229.3 87.5-316.8 0c-12.5-12.5-12.5-32.8 0-45.3s32.8-12.5 45.3 0c62.5 62.5 163.8 62.5 226.3 0s62.5-163.8 0-226.3c-62.2-62.2-162.7-62.5-225.3-1L185 183c6.9 6.9 8.9 17.2 5.2 26.2s-12.5 14.8-22.2 14.8L48.5 224z"/></svg>`);
    processedHtml = processedHtml.replace(/<img\s+([^>]*)\s*src="[^"]*"\s+([^>]*)\s*data-lazy-src="([^"]*)"\s*([^>]*)>/g, '<img $1 $2 src="$3" $4>');
    return processedHtml;
  };
  return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "pb-16", children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", { className: "text-xl font-semibold mb-4", children: "Instructions" }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 70,
      columnNumber: 13
    }, this),
    steps && steps.length > 0 ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "space-y-2", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "mb-4 text-gray-500 text-sm", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex items-center gap-2", children: [
        /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "font-medium", children: "Progression :" }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 74,
          columnNumber: 29
        }, this),
        /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
          completedSteps.length,
          "/",
          steps.length,
          " \xE9tapes termin\xE9es"
        ] }, void 0, true, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 75,
          columnNumber: 29
        }, this)
      ] }, void 0, true, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 73,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 72,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("ol", { className: "space-y-2", children: steps.map((step) => {
        const isCompleted = completedSteps.includes(step.stepNumber);
        const isActive = currentStep === step.stepNumber;
        return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(
          "li",
          {
            id: `recipe-step-${step.stepNumber}`,
            className: `flex p-3 rounded-lg transition-colors cursor-pointer ${isActive ? "bg-rose-50 border-l-4 border-rose-500" : isCompleted ? "bg-gray-50" : ""}`,
            onClick: () => onStepClick(step.stepNumber),
            onKeyDown: (e) => {
              if (e.key === "Enter" || e.key === " ") {
                onStepClick(step.stepNumber);
              }
            },
            tabIndex: 0,
            role: "button",
            "aria-pressed": isActive,
            children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex items-start", children: [
              /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: `flex-shrink-0 w-8 h-8 ${isCompleted ? "bg-gray-200 text-gray-500" : isActive ? "bg-rose-100 text-rose-600" : "bg-gray-100 text-gray-600"} rounded-full flex items-center justify-center font-bold mr-4 transition-colors`, children: isCompleted ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M5 13l4 4L19 7" }, void 0, false, {
                fileName: "app/components/RecipeModal.tsx",
                lineNumber: 92,
                columnNumber: 53
              }, this) }, void 0, false, {
                fileName: "app/components/RecipeModal.tsx",
                lineNumber: 91,
                columnNumber: 60
              }, this) : step.stepNumber }, void 0, false, {
                fileName: "app/components/RecipeModal.tsx",
                lineNumber: 90,
                columnNumber: 41
              }, this),
              /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "pt-1 flex-1", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: `${isCompleted ? "text-gray-400 opacity-70" : "text-gray-700"} transition-colors`, dangerouslySetInnerHTML: {
                __html: processHtml(step.instruction)
              } }, void 0, false, {
                fileName: "app/components/RecipeModal.tsx",
                lineNumber: 96,
                columnNumber: 45
              }, this) }, void 0, false, {
                fileName: "app/components/RecipeModal.tsx",
                lineNumber: 95,
                columnNumber: 41
              }, this)
            ] }, void 0, true, {
              fileName: "app/components/RecipeModal.tsx",
              lineNumber: 89,
              columnNumber: 37
            }, this)
          },
          step.id,
          false,
          {
            fileName: "app/components/RecipeModal.tsx",
            lineNumber: 82,
            columnNumber: 18
          },
          this
        );
      }) }, void 0, false, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 78,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 71,
      columnNumber: 42
    }, this) : (
      // eslint-disable-next-line react/no-unescaped-entities
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", { className: "text-gray-500 italic", children: "Aucune instruction n'est sp\xE9cifi\xE9e pour cette recette." }, void 0, false, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 106,
        columnNumber: 5
      }, this)
    )
  ] }, void 0, true, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 69,
    columnNumber: 10
  }, this);
};
_c2 = InstructionsTab;
var DescriptionTab = ({
  description
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h2", { className: "text-xl font-semibold mb-4", children: "Description" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 115,
    columnNumber: 9
  }, this),
  description ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "text-m mb-3", dangerouslySetInnerHTML: {
    __html: description
  } }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 116,
    columnNumber: 24
  }, this) : (
    // eslint-disable-next-line react/no-unescaped-entities
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", { className: "text-gray-500 italic", children: "Aucune description n'est sp\xE9cifi\xE9e pour cette recette." }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 120,
      columnNumber: 3
    }, this)
  )
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 114,
  columnNumber: 7
}, this);
_c3 = DescriptionTab;
function RecipeModal({
  recipeId,
  basicRecipe,
  isOpen,
  onClose,
  isAuthenticated = false
}) {
  _s();
  const modalRef = (0, import_react.useRef)(null);
  const [selectedTab, setSelectedTab] = (0, import_react.useState)("ingredients");
  const tabs = ["ingredients", "instructions", "description"];
  const [completedSteps, setCompletedSteps] = (0, import_react.useState)([]);
  const [currentStep, setCurrentStep] = (0, import_react.useState)(null);
  const [currentTabIndex, setCurrentTabIndex] = (0, import_react.useState)(0);
  const [isAnimating, setIsAnimating] = (0, import_react.useState)(false);
  const [swipeDirection, setSwipeDirection] = (0, import_react.useState)(null);
  const [swipeProgress, setSwipeProgress] = (0, import_react.useState)(0);
  const recipeDetailsFetcher = useFetcher();
  const favoriteFetcher = useFetcher();
  const menuFetcher = useFetcher();
  const recipe = recipeDetailsFetcher.data?.recipe || basicRecipe;
  const isLoading = recipeDetailsFetcher.state === "loading";
  const inFavorites = Boolean(recipe?.isFavorite);
  const isAdded = Boolean(recipe?.isInMenu);
  (0, import_react.useEffect)(() => {
    if (isOpen && recipeId) {
      recipeDetailsFetcher.load(`/api/recipes?id=${recipeId}`);
    }
  }, [isOpen, recipeId]);
  (0, import_react.useEffect)(() => {
    if (!isOpen)
      return;
    const handleKeyDown = (e) => {
      if (e.key === "Escape")
        onClose();
    };
    const handleClickOutside = (event) => {
      if (modalRef.current && !modalRef.current.contains(event.target)) {
        onClose();
      }
    };
    document.addEventListener("keydown", handleKeyDown);
    document.addEventListener("mousedown", handleClickOutside);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", handleKeyDown);
      document.removeEventListener("mousedown", handleClickOutside);
      document.body.style.overflow = "auto";
    };
  }, [isOpen, onClose]);
  const progressWipeForValidate = 20;
  const swipeHandlers = useSwipeable({
    onSwipeStart: () => {
      setIsAnimating(true);
    },
    onSwiping: (event) => {
      const width = modalRef.current?.clientWidth || 300;
      const progress = Math.min(Math.abs(event.deltaX) / width * 100, 100);
      setSwipeProgress(progress);
      setSwipeDirection(event.dir === "Left" ? "left" : "right");
    },
    onSwipedLeft: () => {
      if (currentTabIndex < tabs.length - 1 && swipeProgress >= progressWipeForValidate) {
        setSelectedTab(tabs[currentTabIndex + 1]);
      }
      resetSwipeState();
    },
    onSwipedRight: () => {
      if (currentTabIndex > 0 && swipeProgress >= progressWipeForValidate) {
        setSelectedTab(tabs[currentTabIndex - 1]);
      }
      resetSwipeState();
    },
    onSwiped: () => {
      resetSwipeState();
    },
    delta: 10,
    //preventDefaultTouchmoveEvent: true,
    trackTouch: true,
    trackMouse: false
  });
  const resetSwipeState = () => {
    setIsAnimating(false);
    setSwipeProgress(0);
    setSwipeDirection(null);
  };
  (0, import_react.useEffect)(() => {
    setCurrentTabIndex(tabs.indexOf(selectedTab));
  }, [selectedTab, tabs]);
  const handleAddToMenu = () => {
    menuFetcher.submit({
      recipeId: recipeId.toString()
    }, {
      method: "post",
      action: "/api/menu"
    });
  };
  const handleToggleFavorite = () => {
    favoriteFetcher.submit({
      recipeId: recipeId.toString(),
      action: inFavorites ? "remove" : "add"
    }, {
      method: "post",
      action: "/api/favorites"
    });
  };
  const navigateToNextStep = () => {
    if (!recipe.steps || recipe.steps.length === 0)
      return;
    if (currentStep) {
      setCompletedSteps((prev) => {
        if (!prev.includes(currentStep)) {
          return [...prev, currentStep];
        }
        return prev;
      });
    }
    const currentIndex = currentStep ? recipe.steps.findIndex((step) => step.stepNumber === currentStep) : -1;
    const nextIndex = currentIndex + 1;
    if (nextIndex < recipe.steps.length) {
      const nextStepNumber = recipe.steps[nextIndex].stepNumber;
      setCurrentStep(nextStepNumber);
      const stepElement = document.getElementById(`recipe-step-${nextStepNumber}`);
      if (stepElement) {
        stepElement.scrollIntoView({
          behavior: "smooth",
          block: "center"
        });
      }
    }
  };
  const handleStepClick = (stepNumber) => {
    if (completedSteps.includes(stepNumber)) {
      setCompletedSteps((prev) => prev.filter((step) => step !== stepNumber));
      if (currentStep !== stepNumber) {
        setCurrentStep(stepNumber);
      }
      return;
    }
    if (currentStep && currentStep !== stepNumber) {
      const currentIndex = recipe.steps?.findIndex((step) => step.stepNumber === currentStep) ?? -1;
      const clickedIndex = recipe.steps?.findIndex((step) => step.stepNumber === stepNumber) ?? -1;
      if (clickedIndex > currentIndex) {
        setCompletedSteps((prev) => {
          if (!prev.includes(currentStep)) {
            return [...prev, currentStep];
          }
          return prev;
        });
      }
    }
    setCurrentStep(stepNumber);
  };
  const navigateToPrevStep = () => {
    if (!recipe.steps || recipe.steps.length === 0)
      return;
    const currentIndex = currentStep ? recipe.steps.findIndex((step) => step.stepNumber === currentStep) : recipe.steps.length;
    const prevIndex = currentIndex - 1;
    if (prevIndex >= 0) {
      const prevStepNumber = recipe.steps[prevIndex].stepNumber;
      setCurrentStep(prevStepNumber);
      const stepElement = document.getElementById(`recipe-step-${prevStepNumber}`);
      if (stepElement) {
        stepElement.scrollIntoView({
          behavior: "smooth",
          block: "center"
        });
      }
    }
  };
  if (!isOpen || !recipe)
    return null;
  return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "fixed inset-0 bg-gray-500 bg-opacity-75 z-50 flex items-center justify-center", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "bg-white w-full h-full md:h-screen max-h-screen rounded-none shadow-xl overflow-hidden flex flex-col", ref: modalRef, children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(RecipeHeader, { recipe, onClose, isAuthenticated, inFavorites, isAdded, handleToggleFavorite, handleAddToMenu, favoriteFetcher, menuFetcher }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 338,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(RecipeMetadata, { recipe }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 341,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex-1 overflow-hidden overflow-y-auto flex flex-col", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabNavigation, { selectedTab, setSelectedTab }, void 0, false, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 345,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: `flex-1 overflow-hidden`, ...swipeHandlers, children: isLoading ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(LoadingSpinner, {}, void 0, false, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 349,
        columnNumber: 38
      }, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "h-full flex transition-transform duration-300 ease-out", style: {
        width: `${tabs.length * 100}%`,
        transform: isAnimating && swipeProgress > 0 ? `translateX(calc(-${currentTabIndex * 100 / tabs.length}% + ${swipeDirection === "left" ? "-" : ""}${swipeProgress / tabs.length}%))` : `translateX(-${currentTabIndex * 100 / tabs.length}%)`
      }, children: [
        /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex-grow w-full overflow-y-auto", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "p-6", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(IngredientsTab, { ingredients: recipe.ingredients }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 356,
          columnNumber: 41
        }, this) }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 355,
          columnNumber: 37
        }, this) }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 354,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex-grow w-full overflow-y-auto", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "p-6", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(InstructionsTab, { steps: recipe.steps, completedSteps, currentStep, onStepClick: handleStepClick, onNextStep: navigateToNextStep, onPrevStep: navigateToPrevStep }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 363,
          columnNumber: 41
        }, this) }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 362,
          columnNumber: 37
        }, this) }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 361,
          columnNumber: 33
        }, this),
        /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex-grow w-full overflow-y-auto", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "p-6", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(DescriptionTab, { description: recipe?.description || void 0 }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 370,
          columnNumber: 41
        }, this) }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 369,
          columnNumber: 37
        }, this) }, void 0, false, {
          fileName: "app/components/RecipeModal.tsx",
          lineNumber: 368,
          columnNumber: 33
        }, this)
      ] }, void 0, true, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 349,
        columnNumber: 59
      }, this) }, void 0, false, {
        fileName: "app/components/RecipeModal.tsx",
        lineNumber: 348,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 344,
      columnNumber: 17
    }, this),
    recipe.sourceUrl && /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(RecipeSource, { url: recipe.sourceUrl }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 378,
      columnNumber: 38
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 336,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 335,
    columnNumber: 10
  }, this);
}
_s(RecipeModal, "7tdAHMffCU2MqP3z+Pqjm6Ms9mM=", false, function() {
  return [useFetcher, useFetcher, useFetcher, useSwipeable];
});
_c4 = RecipeModal;
var RecipeHeader = ({
  recipe,
  onClose,
  isAuthenticated,
  inFavorites,
  isAdded,
  handleToggleFavorite,
  handleAddToMenu,
  favoriteFetcher,
  menuFetcher
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "relative", children: [
  recipe.imageUrl ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "h-48 sm:h-64 w-full bg-cover bg-center", style: {
    backgroundImage: `url(${recipe.imageUrl})`
  }, children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute inset-0 bg-gradient-to-t from-black opacity-60" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 403,
    columnNumber: 17
  }, this) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 400,
    columnNumber: 28
  }, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "h-48 sm:h-64 w-full bg-gray-200 flex items-center justify-center", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-16 h-16 text-gray-400", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 406,
    columnNumber: 21
  }, this) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 405,
    columnNumber: 17
  }, this) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 404,
    columnNumber: 22
  }, this),
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "absolute bottom-0 left-0 w-full p-6 text-white", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h1", { className: "text-2xl font-bold mb-2 text-shadow", children: recipe.title }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 412,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 411,
    columnNumber: 9
  }, this),
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", { onClick: onClose, className: "absolute top-4 right-4 bg-white bg-opacity-80 p-2 rounded-full shadow-md hover:bg-opacity-100 transition-all", "aria-label": "Fermer", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-5 h-5 text-gray-800", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 418,
    columnNumber: 17
  }, this) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 417,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 416,
    columnNumber: 9
  }, this),
  isAuthenticated && /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(FavoriteButton, { inFavorites, onClick: handleToggleFavorite, isSubmitting: favoriteFetcher.state !== "idle" }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 424,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MenuButton, { isAdded, onClick: handleAddToMenu, isSubmitting: menuFetcher.state !== "idle" }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 425,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 423,
    columnNumber: 29
  }, this)
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 399,
  columnNumber: 7
}, this);
_c5 = RecipeHeader;
var FavoriteButton = ({
  inFavorites,
  onClick,
  isSubmitting
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", { onClick, disabled: isSubmitting, className: "absolute top-4 left-4 bg-white bg-opacity-80 p-2 rounded-full shadow-md hover:bg-opacity-100 transition-all", "aria-label": inFavorites ? "Retirer des favoris" : "Ajouter aux favoris", children: isSubmitting ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-5 h-5 animate-spin text-rose-500", fill: "none", viewBox: "0 0 24 24", children: [
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 437,
    columnNumber: 17
  }, this),
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 438,
    columnNumber: 17
  }, this)
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 436,
  columnNumber: 25
}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: `w-5 h-5 ${inFavorites ? "text-rose-500 fill-current" : "text-gray-500"}`, fill: inFavorites ? "currentColor" : "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 440,
  columnNumber: 17
}, this) }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 439,
  columnNumber: 22
}, this) }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 435,
  columnNumber: 7
}, this);
_c6 = FavoriteButton;
var MenuButton = ({
  isAdded,
  onClick,
  isSubmitting
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", { onClick, disabled: isSubmitting || isAdded, className: `absolute top-4 left-16 bg-white bg-opacity-80 p-2 rounded-full shadow-md hover:bg-opacity-100 transition-all ${isAdded ? "border border-green-400 text-green-600" : "text-gray-700"}`, "aria-label": isAdded ? "D\xE9j\xE0 dans le menu" : "Ajouter au menu", children: isSubmitting ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-5 h-5 animate-spin text-rose-500", fill: "none", viewBox: "0 0 24 24", children: [
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 452,
    columnNumber: 17
  }, this),
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 453,
    columnNumber: 17
  }, this)
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 451,
  columnNumber: 25
}, this) : isAdded ? /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-5 h-5 text-green-600", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: [
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 455,
    columnNumber: 17
  }, this),
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9 14l2 2 4-4" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 456,
    columnNumber: 17
  }, this)
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 454,
  columnNumber: 32
}, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-5 h-5 text-gray-700", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 458,
  columnNumber: 17
}, this) }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 457,
  columnNumber: 22
}, this) }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 450,
  columnNumber: 7
}, this);
_c7 = MenuButton;
var RecipeMetadata = ({
  recipe
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "border-b border-gray-200 px-2 py-2", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex flex-wrap justify-around text-xs", children: [
  recipe.preparationTime && /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MetadataItem, { icon: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 468,
    columnNumber: 60
  }, this), label: `${recipe.preparationTime} min` }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 468,
    columnNumber: 40
  }, this),
  recipe.cookingTime && /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MetadataItem, { icon: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M17.657 18.657A8 8 0 016.343 7.343S7 9 9 10c0-2 .5-5 2.986-7C14 5 16.09 5.777 17.656 7.343A7.975 7.975 0 0120 13a7.975 7.975 0 01-2.343 5.657z" }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 471,
      columnNumber: 25
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9.879 16.121A3 3 0 1012.015 11L11 14H9c0 .768.293 1.536.879 2.121z" }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 472,
      columnNumber: 25
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 470,
    columnNumber: 56
  }, this), label: recipe.cookingTime.toString() }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 470,
    columnNumber: 36
  }, this),
  recipe.difficulty && /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MetadataItem, { icon: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M13 10V3L4 14h7v7l9-11h-7z" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 475,
    columnNumber: 55
  }, this), label: recipe.difficulty }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 475,
    columnNumber: 35
  }, this),
  recipe.servings && /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MetadataItem, { icon: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M17 20h5v-2a3 3 0 00-5.356-1.857M17 20H7m10 0v-2c0-.656-.126-1.283-.356-1.857M7 20H2v-2a3 3 0 015.356-1.857M7 20v-2c0-.656.126-1.283.356-1.857m0 0a5.002 5.002 0 019.288 0M15 7a3 3 0 11-6 0 3 3 0 016 0zm6 3a2 2 0 11-4 0 2 2 0 014 0zM7 10a2 2 0 11-4 0 2 2 0 014 0z" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 477,
    columnNumber: 53
  }, this), label: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(import_jsx_dev_runtime.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "font-medium", children: recipe.servings }, void 0, false, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 478,
      columnNumber: 25
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "text-gray-500 ml-1", children: [
      "portion",
      recipe.servings > 1 ? "s" : ""
    ] }, void 0, true, {
      fileName: "app/components/RecipeModal.tsx",
      lineNumber: 479,
      columnNumber: 25
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 477,
    columnNumber: 398
  }, this) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 477,
    columnNumber: 33
  }, this)
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 467,
  columnNumber: 9
}, this) }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 466,
  columnNumber: 7
}, this);
_c8 = RecipeMetadata;
var MetadataItem = ({
  icon,
  label
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "px-2 py-1 flex items-center", children: [
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-4 h-4 mr-1 text-gray-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: icon }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 490,
    columnNumber: 9
  }, this),
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "font-medium", children: label }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 494,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 493,
    columnNumber: 9
  }, this)
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 489,
  columnNumber: 7
}, this);
_c9 = MetadataItem;
var TabNavigation = ({
  selectedTab,
  setSelectedTab
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "border-b border-gray-200", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("nav", { className: "flex justify-between items-center", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex", children: [
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabButton, { isSelected: selectedTab === "ingredients", onClick: () => setSelectedTab("ingredients"), label: "Ingr\xE9dients" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 506,
    columnNumber: 17
  }, this),
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabButton, { isSelected: selectedTab === "instructions", onClick: () => setSelectedTab("instructions"), label: "Instructions" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 507,
    columnNumber: 17
  }, this),
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(TabButton, { isSelected: selectedTab === "description", onClick: () => setSelectedTab("description"), label: "Description" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 508,
    columnNumber: 17
  }, this)
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 505,
  columnNumber: 13
}, this) }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 504,
  columnNumber: 9
}, this) }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 503,
  columnNumber: 7
}, this);
_c10 = TabNavigation;
var TabButton = ({
  isSelected,
  onClick,
  label
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", { onClick, className: `py-4 px-4 font-medium text-sm focus:outline-none ${isSelected ? "border-b-2 border-rose-500 text-rose-500" : "text-gray-500 hover:text-gray-700"}`, children: label }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 519,
  columnNumber: 7
}, this);
_c11 = TabButton;
var LoadingSpinner = () => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex justify-center items-center h-40", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "animate-spin h-10 w-10 text-rose-500", xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", children: [
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 527,
    columnNumber: 13
  }, this),
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 528,
    columnNumber: 13
  }, this)
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 526,
  columnNumber: 9
}, this) }, void 0, false, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 525,
  columnNumber: 30
}, this);
_c12 = LoadingSpinner;
var RecipeSource = ({
  url
}) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "px-6 py-2 text-xs text-center text-gray-500 border-t", children: [
  "Voir la recette sur",
  /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("a", { href: url, target: "_blank", rel: "noopener noreferrer", className: "text-rose-500 hover:underline", onClick: (e) => e.stopPropagation(), children: " " + new URL(url).hostname }, void 0, false, {
    fileName: "app/components/RecipeModal.tsx",
    lineNumber: 538,
    columnNumber: 9
  }, this)
] }, void 0, true, {
  fileName: "app/components/RecipeModal.tsx",
  lineNumber: 536,
  columnNumber: 7
}, this);
_c13 = RecipeSource;
var _c;
var _c2;
var _c3;
var _c4;
var _c5;
var _c6;
var _c7;
var _c8;
var _c9;
var _c10;
var _c11;
var _c12;
var _c13;
$RefreshReg$(_c, "IngredientsTab");
$RefreshReg$(_c2, "InstructionsTab");
$RefreshReg$(_c3, "DescriptionTab");
$RefreshReg$(_c4, "RecipeModal");
$RefreshReg$(_c5, "RecipeHeader");
$RefreshReg$(_c6, "FavoriteButton");
$RefreshReg$(_c7, "MenuButton");
$RefreshReg$(_c8, "RecipeMetadata");
$RefreshReg$(_c9, "MetadataItem");
$RefreshReg$(_c10, "TabNavigation");
$RefreshReg$(_c11, "TabButton");
$RefreshReg$(_c12, "LoadingSpinner");
$RefreshReg$(_c13, "RecipeSource");
window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

// app/components/BoxRecipe.tsx
var import_jsx_dev_runtime2 = __toESM(require_jsx_dev_runtime(), 1);
if (!window.$RefreshReg$ || !window.$RefreshSig$ || !window.$RefreshRuntime$) {
  console.warn("remix:hmr: React Fast Refresh only works when the Remix compiler is running in development mode.");
} else {
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    window.$RefreshRuntime$.register(type, '"app/components/BoxRecipe.tsx"' + id);
  };
  window.$RefreshSig$ = window.$RefreshRuntime$.createSignatureFunctionForTransform;
}
var prevRefreshReg;
var prevRefreshSig;
var _s2 = $RefreshSig$();
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/components/BoxRecipe.tsx"
  );
  import.meta.hot.lastModified = "1744093880587.1787";
}
function BoxRecipe({
  recipe,
  readOnly = false,
  compact = false
}) {
  _s2();
  const [isModalOpen, setIsModalOpen] = (0, import_react3.useState)(false);
  const {
    isAuthenticated
  } = useOutletContext() || {
    isAuthenticated: false
  };
  const menuFetcher = useFetcher();
  const favoriteFetcher = useFetcher();
  const [isAddingToMenu, setIsAddingToMenu] = (0, import_react3.useState)(false);
  const [isFavorite, setIsFavorite] = (0, import_react3.useState)(recipe.isFavorite || false);
  const handleAddToMenu = (e) => {
    e.stopPropagation();
    setIsAddingToMenu(true);
    menuFetcher.submit({
      recipeId: recipe.id.toString()
    }, {
      method: "post",
      action: "/api/menu"
    });
  };
  const handleToggleFavorite = (e) => {
    e.stopPropagation();
    const newFavoriteState = !isFavorite;
    setIsFavorite(newFavoriteState);
    favoriteFetcher.submit({
      recipeId: recipe.id.toString(),
      action: newFavoriteState ? "add" : "remove"
    }, {
      method: "post",
      action: "/api/favorites"
    });
  };
  (0, import_react3.useEffect)(() => {
    const handlePopState = (event) => {
      event.preventDefault();
      setIsModalOpen(false);
    };
    window.addEventListener("popstate", handlePopState);
    return () => {
      window.removeEventListener("popstate", handlePopState);
    };
  }, []);
  const openModal = () => {
    window.history.pushState(null, "", "#modal");
    setIsModalOpen(true);
  };
  if (menuFetcher.state === "idle" && isAddingToMenu) {
    setIsAddingToMenu(false);
  }
  return /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)(import_jsx_dev_runtime2.Fragment, { children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)(
      "div",
      {
        className: "box-recipe bg-white rounded-lg shadow-md overflow-hidden h-full flex flex-col cursor-pointer hover:shadow-lg transition-shadow relative",
        onClick: () => openModal(),
        role: "button",
        children: [
          /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: `relative ${compact ? "h-24" : "h-44"}`, children: [
            recipe.imageUrl ? /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "h-full w-full bg-cover bg-center", style: {
              backgroundImage: `url(${recipe.imageUrl})`
            } }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 87,
              columnNumber: 40
            }, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "h-full w-full bg-gray-200 flex items-center justify-center", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "w-12 h-12 text-gray-400", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M4 16l4.586-4.586a2 2 0 012.828 0L16 16m-2-2l1.586-1.586a2 2 0 012.828 0L20 14m-6-6h.01M6 20h12a2 2 0 002-2V6a2 2 0 00-2-2H6a2 2 0 00-2 2v12a2 2 0 002 2z" }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 91,
              columnNumber: 33
            }, this) }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 90,
              columnNumber: 29
            }, this) }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 89,
              columnNumber: 21
            }, this),
            recipe.note && !compact && /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "absolute top-2 left-2 bg-white bg-opacity-90 text-amber-500 font-semibold text-sm rounded-md px-2 py-1 flex items-center", children: [
              /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "w-4 h-4 mr-1", fill: "currentColor", viewBox: "0 0 20 20", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { d: "M9.049 2.927c.3-.921 1.603-.921 1.902 0l1.07 3.292a1 1 0 00.95.69h3.462c.969 0 1.371 1.24.588 1.81l-2.8 2.034a1 1 0 00-.364 1.118l1.07 3.292c.3.921-.755 1.688-1.54 1.118l-2.8-2.034a1 1 0 00-1.175 0l-2.8 2.034c-.784.57-1.838-.197-1.539-1.118l1.07-3.292a1 1 0 00-.364-1.118L2.98 8.72c-.783-.57-.38-1.81.588-1.81h3.461a1 1 0 00.951-.69l1.07-3.292z" }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 98,
                columnNumber: 33
              }, this) }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 97,
                columnNumber: 29
              }, this),
              recipe.note,
              /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("span", { className: "font-light text-gray-700 text-xs pl-1", children: `(${recipe.voteNumber})` }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 101,
                columnNumber: 29
              }, this)
            ] }, void 0, true, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 96,
              columnNumber: 49
            }, this),
            recipe.isVege && /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "absolute bottom-2 right-2 bg-green-100 bg-opacity-90 text-green-600 font-semibold text-xs rounded-md px-2 py-1 flex items-center", children: [
              /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "w-4 h-4 mr-1", fill: "currentColor", viewBox: "0 0 20 20", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { fillRule: "evenodd", d: "M6.293 9.293a1 1 0 011.414 0L10 11.586l2.293-2.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z", clipRule: "evenodd" }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 107,
                columnNumber: 33
              }, this) }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 106,
                columnNumber: 29
              }, this),
              "V\xE9g\xE9"
            ] }, void 0, true, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 105,
              columnNumber: 39
            }, this)
          ] }, void 0, true, {
            fileName: "app/components/BoxRecipe.tsx",
            lineNumber: 86,
            columnNumber: 17
          }, this),
          isAuthenticated && /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: `absolute top-2 z-10 flex space-x-2 
                        ${compact ? "left-2" : "right-2"}`, children: [
            /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { onClick: handleToggleFavorite, disabled: favoriteFetcher.state !== "idle", className: `w-8 h-8 rounded-full flex items-center justify-center 
                                ${isFavorite ? "bg-rose-100 text-rose-500" : "bg-white bg-opacity-80 hover:bg-opacity-100 text-gray-400 shadow-md"}`, "aria-label": "Ajouter aux favoris", children: favoriteFetcher.state !== "idle" ? /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "animate-spin h-5 w-5 text-rose-500", fill: "none", viewBox: "0 0 24 24", children: [
              /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 120,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 121,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 119,
              columnNumber: 65
            }, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "w-5 h-5", fill: isFavorite ? "currentColor" : "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M4.318 6.318a4.5 4.5 0 000 6.364L12 20.364l7.682-7.682a4.5 4.5 0 00-6.364-6.364L12 7.636l-1.318-1.318a4.5 4.5 0 00-6.364 0z" }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 123,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 122,
              columnNumber: 42
            }, this) }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 117,
              columnNumber: 25
            }, this),
            /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { onClick: handleAddToMenu, disabled: isAddingToMenu || recipe.isInMenu, className: `w-8 h-8 rounded-full flex items-center justify-center 
                                ${recipe.isInMenu ? "bg-green-100 text-green-600 cursor-default" : "bg-white bg-opacity-80 hover:bg-opacity-100 text-gray-700 shadow-md"}`, "aria-label": "Ajouter au menu", children: isAddingToMenu ? /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "animate-spin h-5 w-5 text-teal-500", fill: "none", viewBox: "0 0 24 24", children: [
              /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 131,
                columnNumber: 37
              }, this),
              /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 132,
                columnNumber: 37
              }, this)
            ] }, void 0, true, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 130,
              columnNumber: 47
            }, this) : recipe.isInMenu ? /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "w-5 h-5", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M5 13l4 4L19 7" }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 134,
              columnNumber: 37
            }, this) }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 133,
              columnNumber: 60
            }, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("span", { className: "text-lg font-bold", children: "+" }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 135,
              columnNumber: 42
            }, this) }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 128,
              columnNumber: 25
            }, this)
          ] }, void 0, true, {
            fileName: "app/components/BoxRecipe.tsx",
            lineNumber: 114,
            columnNumber: 37
          }, this),
          /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "p-4 flex-1 flex flex-col", children: [
            /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("h3", { className: `text-lg font-semibold leading-tight mb-2 text-gray-900 line-clamp-1 overflow-hidden text-ellipsis ${compact && "text-sm line-clamp-2"}`, children: recipe.title }, void 0, false, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 141,
              columnNumber: 21
            }, this),
            /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "mt-auto flex justify-between text-xs text-gray-500", children: [
              /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { children: recipe.preparationTime && /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("span", { children: [
                recipe.preparationTime,
                " min"
              ] }, void 0, true, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 146,
                columnNumber: 56
              }, this) }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 145,
                columnNumber: 25
              }, this),
              /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { children: recipe.difficulty }, void 0, false, {
                fileName: "app/components/BoxRecipe.tsx",
                lineNumber: 148,
                columnNumber: 25
              }, this)
            ] }, void 0, true, {
              fileName: "app/components/BoxRecipe.tsx",
              lineNumber: 144,
              columnNumber: 21
            }, this)
          ] }, void 0, true, {
            fileName: "app/components/BoxRecipe.tsx",
            lineNumber: 140,
            columnNumber: 17
          }, this)
        ]
      },
      void 0,
      true,
      {
        fileName: "app/components/BoxRecipe.tsx",
        lineNumber: 83,
        columnNumber: 13
      },
      this
    ),
    isModalOpen && /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)(RecipeModal, { recipeId: recipe.id, basicRecipe: recipe, isOpen: isModalOpen, onClose: () => setIsModalOpen(false), isAuthenticated }, void 0, false, {
      fileName: "app/components/BoxRecipe.tsx",
      lineNumber: 154,
      columnNumber: 29
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/BoxRecipe.tsx",
    lineNumber: 82,
    columnNumber: 10
  }, this);
}
_s2(BoxRecipe, "VRc74GGSvaO9y5dkr4N9KsSv6KU=", false, function() {
  return [useOutletContext, useFetcher, useFetcher];
});
_c14 = BoxRecipe;
var _c14;
$RefreshReg$(_c14, "BoxRecipe");
window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

export {
  BoxRecipe
};
//# sourceMappingURL=/build/_shared/chunk-GAOE5PSX.js.map
