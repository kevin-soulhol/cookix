import {
  __commonJS
} from "/build/_shared/chunk-PNG5AS42.js";

// empty-module:@remix-run/node
var require_node = __commonJS({
  "empty-module:@remix-run/node"(exports, module) {
    module.exports = {};
  }
});

export {
  require_node
};
//# sourceMappingURL=/build/_shared/chunk-G7CHZRZX.js.map
