import {
  BoxRecipe
} from "/build/_shared/chunk-GAOE5PSX.js";
import {
  Layout
} from "/build/_shared/chunk-LTCLDH5B.js";
import {
  require_node
} from "/build/_shared/chunk-G7CHZRZX.js";
import {
  Form,
  useFetcher,
  useLoaderData,
  useNavigation,
  useSearchParams,
  useSubmit
} from "/build/_shared/chunk-BC5VDABJ.js";
import "/build/_shared/chunk-U4FRFQSK.js";
import {
  require_jsx_dev_runtime
} from "/build/_shared/chunk-XGOTYLZ5.js";
import {
  createHotContext
} from "/build/_shared/chunk-MCH5QMAS.js";
import "/build/_shared/chunk-UWV35TSL.js";
import {
  require_react
} from "/build/_shared/chunk-7M6SC7J5.js";
import {
  __toESM
} from "/build/_shared/chunk-PNG5AS42.js";

// app/routes/_index.tsx
var import_node = __toESM(require_node(), 1);
var import_react8 = __toESM(require_react(), 1);

// app/components/FilterPanel.tsx
var import_jsx_dev_runtime = __toESM(require_jsx_dev_runtime(), 1);
if (!window.$RefreshReg$ || !window.$RefreshSig$ || !window.$RefreshRuntime$) {
  console.warn("remix:hmr: React Fast Refresh only works when the Remix compiler is running in development mode.");
} else {
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    window.$RefreshRuntime$.register(type, '"app/components/FilterPanel.tsx"' + id);
  };
  window.$RefreshSig$ = window.$RefreshRuntime$.createSignatureFunctionForTransform;
}
var prevRefreshReg;
var prevRefreshSig;
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/components/FilterPanel.tsx"
  );
  import.meta.hot.lastModified = "1744180771660.0652";
}
function FilterPanel({
  isVisible,
  onClose,
  filters,
  filterValues,
  onUpdateFilter,
  onReset,
  formRef,
  onSubmit,
  setCategory,
  setMealType,
  setMaxPreparationTime,
  setRandomEnabled,
  setOnlyVege
}) {
  if (!isVisible)
    return null;
  const {
    category,
    mealType,
    maxPreparationTime,
    randomEnabled,
    onlyVege
  } = filterValues;
  return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "filter-panel fixed inset-0 bg-gray-500 bg-opacity-75 z-50 flex items-end", onClick: onClose, children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { onClick: (e) => e.stopPropagation(), className: "bg-white w-full rounded-t-xl p-5 transform transition-transform max-h-[90vh] overflow-auto", children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex justify-between items-center mb-4", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("h3", { className: "text-lg font-semibold", children: "Filtres" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 56,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", { onClick: onClose, className: "p-2 rounded-full hover:bg-gray-100", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("svg", { className: "w-5 h-5", viewBox: "0 0 24 24", fill: "none", stroke: "currentColor", children: /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 59,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 58,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 57,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 55,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "space-y-5", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(CategoryFilter, { value: category, options: filters.categoryOptions, onChange: (value) => {
        setCategory(value);
        onUpdateFilter("categoryId", value);
      } }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 67,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(MealTypeFilter, { value: mealType, options: filters.mealTypeOptions, onChange: (value) => {
        setMealType(value);
        onUpdateFilter("mealType", value);
      } }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 73,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(PreparationTimeFilter, { value: maxPreparationTime, max: filters.preparationTimeMax, onChange: (value) => {
        setMaxPreparationTime(value);
        onUpdateFilter("maxPreparationTime", value?.toString() || null);
        if (formRef.current)
          onSubmit(formRef.current);
      } }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 79,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Toggle, { label: "Affichage al\xE9atoire", text: "Activer l'affichage al\xE9atoire", enabled: randomEnabled, onChange: () => {
        setRandomEnabled(!randomEnabled);
        const form = formRef.current;
        if (form !== null && form) {
          setTimeout(() => onSubmit(form), 0);
        }
      } }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 86,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)(Toggle, { label: "Seulement les plats v\xE9g\xE9", text: "Activer l'affichage des plats v\xE9g\xE9tariens uniquement", enabled: onlyVege, onChange: () => {
        setOnlyVege(!onlyVege);
        const form = formRef.current;
        if (form !== null && form) {
          setTimeout(() => onSubmit(form), 0);
        }
      } }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 95,
        columnNumber: 21
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex space-x-3 pt-3", children: [
        /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", { type: "button", onClick: onReset, className: "cancel-panel flex-1 py-2 px-4 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50", children: "R\xE9initialiser" }, void 0, false, {
          fileName: "app/components/FilterPanel.tsx",
          lineNumber: 116,
          columnNumber: 25
        }, this),
        /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", { type: "button", onClick: onClose, className: "valid-panel flex-1 py-2 px-4 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-rose-600 hover:bg-rose-700", children: "Appliquer" }, void 0, false, {
          fileName: "app/components/FilterPanel.tsx",
          lineNumber: 119,
          columnNumber: 25
        }, this)
      ] }, void 0, true, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 115,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 65,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/FilterPanel.tsx",
    lineNumber: 53,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "app/components/FilterPanel.tsx",
    lineNumber: 52,
    columnNumber: 10
  }, this);
}
_c = FilterPanel;
function CategoryFilter({
  value,
  options,
  onChange
}) {
  return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", { htmlFor: "categoryId", className: "block text-sm font-medium text-gray-700 mb-1", children: "Cat\xE9gorie" }, void 0, false, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 136,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", { id: "categoryId", name: "categoryId", value, onChange: (e) => onChange(e.target.value), className: "block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-rose-500 focus:border-rose-500 sm:text-sm", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: "", children: "Toutes les cat\xE9gories" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 140,
        columnNumber: 17
      }, this),
      options.map((option) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: option.id.toString(), children: option.title }, option.id, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 141,
        columnNumber: 40
      }, this))
    ] }, void 0, true, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 139,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/FilterPanel.tsx",
    lineNumber: 135,
    columnNumber: 10
  }, this);
}
_c2 = CategoryFilter;
function MealTypeFilter({
  value,
  options,
  onChange
}) {
  return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", { htmlFor: "mealType", className: "block text-sm font-medium text-gray-700 mb-1", children: "Type de repas" }, void 0, false, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 156,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", { id: "mealType", name: "mealType", value, onChange: (e) => onChange(e.target.value), className: "block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-rose-500 focus:border-rose-500 sm:text-sm", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: "", children: "Tous les types" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 160,
        columnNumber: 17
      }, this),
      options.map((option) => /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: option.title, children: option.title }, option.title, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 161,
        columnNumber: 40
      }, this))
    ] }, void 0, true, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 159,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/FilterPanel.tsx",
    lineNumber: 155,
    columnNumber: 10
  }, this);
}
_c3 = MealTypeFilter;
function PreparationTimeFilter({
  value,
  max,
  onChange
}) {
  return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", { htmlFor: "maxPreparationTime", className: "block text-sm font-medium text-gray-700 mb-1", children: [
      "Temps de pr\xE9paration (max ",
      value || max,
      " min)"
    ] }, void 0, true, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 176,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("input", { type: "range", id: "maxPreparationTime", name: "maxPreparationTime", min: "0", max, step: "10", value: value || max, onChange: (e) => onChange(parseInt(e.target.value)), className: "w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer accent-rose-500" }, void 0, false, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 179,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex justify-between text-xs text-gray-500 mt-1", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: "0 min" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 181,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { children: [
        max,
        " min"
      ] }, void 0, true, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 182,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 180,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/FilterPanel.tsx",
    lineNumber: 175,
    columnNumber: 10
  }, this);
}
_c4 = PreparationTimeFilter;
function Toggle({
  label,
  text,
  enabled,
  onChange
}) {
  return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { className: "flex items-center justify-between", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", { htmlFor: "random", className: "text-sm font-medium text-gray-700", children: label }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 197,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("button", { type: "button", onClick: onChange, className: `relative inline-flex flex-shrink-0 h-6 w-11 border-2 border-transparent rounded-full cursor-pointer transition-colors ease-in-out duration-200 focus:outline-none ${enabled ? "bg-rose-500" : "bg-gray-200"}`, role: "switch", "aria-checked": enabled, children: [
        /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { className: "sr-only", children: text }, void 0, false, {
          fileName: "app/components/FilterPanel.tsx",
          lineNumber: 201,
          columnNumber: 21
        }, this),
        /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("span", { "aria-hidden": "true", className: `pointer-events-none inline-block h-5 w-5 rounded-full bg-white shadow transform ring-0 transition ease-in-out duration-200 ${enabled ? "translate-x-5" : "translate-x-0"}` }, void 0, false, {
          fileName: "app/components/FilterPanel.tsx",
          lineNumber: 202,
          columnNumber: 21
        }, this)
      ] }, void 0, true, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 200,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 196,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("p", { className: "mt-1 text-xs text-gray-500", children: text }, void 0, false, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 205,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/FilterPanel.tsx",
    lineNumber: 195,
    columnNumber: 10
  }, this);
}
_c5 = Toggle;
function SortingOptions({
  value,
  onChange
}) {
  return /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("div", { children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("label", { htmlFor: "sort", className: "block text-sm font-medium text-gray-700 mb-1", children: "Trier par" }, void 0, false, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 218,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("select", { id: "sort", name: "sort", value, onChange: (e) => onChange(e.target.value), className: "block w-full pl-3 pr-10 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-rose-500 focus:border-rose-500 sm:text-sm", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: "title-asc", children: "Titre (A-Z)" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 222,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: "title-desc", children: "Titre (Z-A)" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 223,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: "preparationTime-asc", children: "Temps de pr\xE9paration (croissant)" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 224,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: "preparationTime-desc", children: "Temps de pr\xE9paration (d\xE9croissant)" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 225,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: "note-desc", children: "Note (d\xE9croissant)" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 226,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime.jsxDEV)("option", { value: "note-asc", children: "Note (croissant)" }, void 0, false, {
        fileName: "app/components/FilterPanel.tsx",
        lineNumber: 227,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/FilterPanel.tsx",
      lineNumber: 221,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/FilterPanel.tsx",
    lineNumber: 217,
    columnNumber: 10
  }, this);
}
_c6 = SortingOptions;
var _c;
var _c2;
var _c3;
var _c4;
var _c5;
var _c6;
$RefreshReg$(_c, "FilterPanel");
$RefreshReg$(_c2, "CategoryFilter");
$RefreshReg$(_c3, "MealTypeFilter");
$RefreshReg$(_c4, "PreparationTimeFilter");
$RefreshReg$(_c5, "Toggle");
$RefreshReg$(_c6, "SortingOptions");
window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

// app/components/SearchBarIndex.tsx
var import_jsx_dev_runtime2 = __toESM(require_jsx_dev_runtime(), 1);
if (!window.$RefreshReg$ || !window.$RefreshSig$ || !window.$RefreshRuntime$) {
  console.warn("remix:hmr: React Fast Refresh only works when the Remix compiler is running in development mode.");
} else {
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    window.$RefreshRuntime$.register(type, '"app/components/SearchBarIndex.tsx"' + id);
  };
  window.$RefreshSig$ = window.$RefreshRuntime$.createSignatureFunctionForTransform;
}
var prevRefreshReg;
var prevRefreshSig;
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/components/SearchBarIndex.tsx"
  );
  import.meta.hot.lastModified = "1744180482555.6174";
}
function SearchBar({
  value,
  onChange,
  onClear,
  onFilterClick,
  totalRecipes
}) {
  return /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "searchbar sticky top-[4rem] z-20 pb-1 pt-4", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "relative", children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("input", { type: "text", name: "search", id: "search", placeholder: "Rechercher une recette...", value, onChange, className: "block w-full pl-10 pr-16 py-3 border border-gray-300 rounded-lg shadow-sm placeholder-gray-400 focus:outline-none focus:ring-rose-500 focus:border-rose-500 text-base" }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 36,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "absolute inset-y-0 left-0 pl-3 flex items-center", children: value ? /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { type: "button", className: "pr-3 flex items-center", onClick: onClear, children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "h-5 w-5 text-gray-400 hover:text-gray-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M6 18L18 6M6 6l12 12" }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 40,
      columnNumber: 33
    }, this) }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 39,
      columnNumber: 29
    }, this) }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 38,
      columnNumber: 30
    }, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "h-5 w-5 text-gray-400", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 43,
      columnNumber: 29
    }, this) }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 42,
      columnNumber: 37
    }, this) }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 37,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "recipe-number absolute inset-y-0 right-7 pr-3 flex items-center text-xs text-gray-500", children: [
      totalRecipes,
      " recettes"
    ] }, void 0, true, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 48,
      columnNumber: 17
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { type: "button", onClick: onFilterClick, className: "display-filter absolute inset-y-0 right-0 px-3 flex items-center", "aria-label": "Filtrer les recettes", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "w-5 h-5 text-gray-500", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M3 4a1 1 0 011-1h16a1 1 0 011 1v2.586a1 1 0 01-.293.707l-6.414 6.414a1 1 0 00-.293.707V17l-4 4v-6.586a1 1 0 00-.293-.707L3.293 7.293A1 1 0 013 6.586V4z" }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 55,
      columnNumber: 25
    }, this) }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 54,
      columnNumber: 21
    }, this) }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 53,
      columnNumber: 17
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/SearchBarIndex.tsx",
    lineNumber: 35,
    columnNumber: 13
  }, this) }, void 0, false, {
    fileName: "app/components/SearchBarIndex.tsx",
    lineNumber: 34,
    columnNumber: 10
  }, this);
}
_c7 = SearchBar;
function ActiveFilters({
  category,
  mealType,
  maxPreparationTime,
  categoryOptions,
  onyVegeEnabled,
  onCategoryRemove,
  onMealTypeRemove,
  onPrepTimeRemove,
  onOnlyVegeRemove,
  onResetAll
}) {
  if (!category && !mealType && !maxPreparationTime && !onyVegeEnabled)
    return null;
  return /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "flex flex-wrap gap-2 mt-2 mb-2", children: [
    category && /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-indigo-100 text-indigo-800", children: [
      categoryOptions.find((c) => c.id.toString() === category)?.title || "Cat\xE9gorie",
      /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { type: "button", onClick: onCategoryRemove, className: "ml-1.5 h-4 w-4 rounded-full inline-flex items-center justify-center text-indigo-400 hover:bg-indigo-200 hover:text-indigo-600", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "h-3 w-3", viewBox: "0 0 12 12", fill: "none", stroke: "currentColor", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { d: "M8 4l-4 4M4 4l4 4", strokeWidth: "2", strokeLinecap: "round" }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 83,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 82,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 81,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 79,
      columnNumber: 26
    }, this),
    mealType && /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800", children: [
      mealType,
      /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { type: "button", onClick: onMealTypeRemove, className: "ml-1.5 h-4 w-4 rounded-full inline-flex items-center justify-center text-green-400 hover:bg-green-200 hover:text-green-600", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "h-3 w-3", viewBox: "0 0 12 12", fill: "none", stroke: "currentColor", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { d: "M8 4l-4 4M4 4l4 4", strokeWidth: "2", strokeLinecap: "round" }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 92,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 91,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 90,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 88,
      columnNumber: 26
    }, this),
    maxPreparationTime && /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-amber-100 text-amber-800", children: [
      "Max ",
      maxPreparationTime,
      " min",
      /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { type: "button", onClick: onPrepTimeRemove, className: "ml-1.5 h-4 w-4 rounded-full inline-flex items-center justify-center text-amber-400 hover:bg-amber-200 hover:text-amber-600", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "h-3 w-3", viewBox: "0 0 12 12", fill: "none", stroke: "currentColor", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { d: "M8 4l-4 4M4 4l4 4", strokeWidth: "2", strokeLinecap: "round" }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 101,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 100,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 99,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 97,
      columnNumber: 36
    }, this),
    onyVegeEnabled && /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("span", { className: "inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800", children: [
      "V\xE9g\xE9 uniquement",
      /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { type: "button", onClick: onOnlyVegeRemove, className: "ml-1.5 h-4 w-4 rounded-full inline-flex items-center justify-center text-green-400 hover:bg-green-200 hover:text-amber-600", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "h-3 w-3", viewBox: "0 0 12 12", fill: "none", stroke: "currentColor", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { d: "M8 4l-4 4M4 4l4 4", strokeWidth: "2", strokeLinecap: "round" }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 110,
        columnNumber: 29
      }, this) }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 109,
        columnNumber: 25
      }, this) }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 108,
        columnNumber: 21
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 106,
      columnNumber: 32
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { type: "button", onClick: onResetAll, className: "text-xs text-gray-500 hover:text-gray-700 underline", children: "Tout effacer" }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 115,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/SearchBarIndex.tsx",
    lineNumber: 78,
    columnNumber: 10
  }, this);
}
_c22 = ActiveFilters;
function EmptyState({
  onReset
}) {
  return /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "container-result-empty text-center py-12 bg-white rounded-lg shadow-md", children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "mx-auto h-12 w-12 text-gray-400", fill: "none", stroke: "currentColor", viewBox: "0 0 24 24", xmlns: "http://www.w3.org/2000/svg", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { strokeLinecap: "round", strokeLinejoin: "round", strokeWidth: "2", d: "M9.172 16.172a4 4 0 015.656 0M9 10h.01M15 10h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 128,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 127,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("h3", { className: "mt-2 text-lg font-medium text-gray-900", children: "Aucune recette trouv\xE9e" }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 130,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("p", { className: "mt-1 text-sm text-gray-500", children: "Essayez de modifier vos filtres pour voir plus de r\xE9sultats." }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 131,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "mt-6", children: /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("button", { onClick: onReset, className: "inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-rose-600 hover:bg-rose-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-rose-500", children: "R\xE9initialiser les filtres" }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 135,
      columnNumber: 17
    }, this) }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 134,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/SearchBarIndex.tsx",
    lineNumber: 126,
    columnNumber: 10
  }, this);
}
_c32 = EmptyState;
function LoadingIndicator() {
  return /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("div", { className: "loader flex flex-col items-center", children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("svg", { className: "animate-spin h-8 w-8 text-rose-500 mb-2", xmlns: "http://www.w3.org/2000/svg", fill: "none", viewBox: "0 0 24 24", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("circle", { className: "opacity-25", cx: "12", cy: "12", r: "10", stroke: "currentColor", strokeWidth: "4" }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 147,
        columnNumber: 17
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("path", { className: "opacity-75", fill: "currentColor", d: "M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" }, void 0, false, {
        fileName: "app/components/SearchBarIndex.tsx",
        lineNumber: 148,
        columnNumber: 17
      }, this)
    ] }, void 0, true, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 146,
      columnNumber: 13
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime2.jsxDEV)("span", { className: "text-sm text-gray-500", children: "Chargement d'autres recettes..." }, void 0, false, {
      fileName: "app/components/SearchBarIndex.tsx",
      lineNumber: 150,
      columnNumber: 13
    }, this)
  ] }, void 0, true, {
    fileName: "app/components/SearchBarIndex.tsx",
    lineNumber: 145,
    columnNumber: 10
  }, this);
}
_c42 = LoadingIndicator;
var _c7;
var _c22;
var _c32;
var _c42;
$RefreshReg$(_c7, "SearchBar");
$RefreshReg$(_c22, "ActiveFilters");
$RefreshReg$(_c32, "EmptyState");
$RefreshReg$(_c42, "LoadingIndicator");
window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;

// app/hooks/useInfiniteScroll.ts
var import_react = __toESM(require_react(), 1);
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/hooks/useInfiniteScroll.ts"
  );
  import.meta.hot.lastModified = "1743759265588.0916";
}
function useInfiniteScroll({
  hasMore,
  isLoading,
  onLoadMore,
  rootMargin = "200px",
  threshold = 0.1,
  enabled = true
}) {
  const observerRef = (0, import_react.useRef)(null);
  const targetRef = (0, import_react.useRef)(null);
  const setTargetRef = (0, import_react.useCallback)((node) => {
    targetRef.current = node;
  }, []);
  (0, import_react.useEffect)(() => {
    if (!enabled || isLoading || !hasMore)
      return;
    if (observerRef.current) {
      observerRef.current.disconnect();
    }
    observerRef.current = new IntersectionObserver((entries) => {
      if (entries[0]?.isIntersecting) {
        onLoadMore();
      }
    }, {
      rootMargin,
      threshold
    });
    const currentTarget = targetRef.current;
    if (currentTarget) {
      observerRef.current.observe(currentTarget);
    }
    return () => {
      if (observerRef.current) {
        observerRef.current.disconnect();
      }
    };
  }, [enabled, hasMore, isLoading, onLoadMore, rootMargin, threshold]);
  return setTargetRef;
}

// app/hooks/useRecipeFilters.ts
var import_react3 = __toESM(require_react(), 1);

// app/hooks/useDebounce.tsx
var import_react2 = __toESM(require_react(), 1);
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/hooks/useDebounce.tsx"
  );
  import.meta.hot.lastModified = "1743746612792.846";
}
function useDebounce(value, delay) {
  const [debouncedValue, setDebouncedValue] = (0, import_react2.useState)(value);
  (0, import_react2.useEffect)(() => {
    const handler = setTimeout(() => {
      setDebouncedValue(value);
    }, delay);
    return () => {
      clearTimeout(handler);
    };
  }, [value, delay]);
  return debouncedValue;
}

// app/hooks/useRecipeFilters.ts
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/hooks/useRecipeFilters.ts"
  );
  import.meta.hot.lastModified = "1743852620234.8728";
}
function useRecipeFilters(initialState) {
  const [search, setSearch] = (0, import_react3.useState)(initialState.search);
  const [category, setCategory] = (0, import_react3.useState)(initialState.category);
  const [mealType, setMealType] = (0, import_react3.useState)(initialState.mealType);
  const [maxPreparationTime, setMaxPreparationTime] = (0, import_react3.useState)(initialState.maxPreparationTime);
  const [sortBy, setSortBy] = (0, import_react3.useState)(initialState.sortBy);
  const [sortDirection, setSortDirection] = (0, import_react3.useState)(initialState.sortDirection);
  const [randomEnabled, setRandomEnabled] = (0, import_react3.useState)(initialState.randomEnabled);
  const [onlyVege, setOnlyVege] = (0, import_react3.useState)(initialState.onlyVege);
  const debouncedSearch = useDebounce(search, 400);
  const [searchParams, setSearchParams] = useSearchParams();
  (0, import_react3.useEffect)(() => {
    if (debouncedSearch !== initialState.search && debouncedSearch !== searchParams.get("search")) {
      const params = new URLSearchParams();
      if (debouncedSearch)
        params.set("search", debouncedSearch);
      if (category)
        params.set("categoryId", category);
      if (mealType)
        params.set("mealType", mealType);
      if (maxPreparationTime)
        params.set("maxPreparationTime", maxPreparationTime.toString());
      params.set("sortBy", sortBy);
      params.set("sortDirection", sortDirection);
      params.set("random", randomEnabled ? "true" : "false");
      params.set("onlyVege", onlyVege ? "true" : "false");
      params.set("page", "1");
      setSearchParams(params);
    }
  }, [debouncedSearch, initialState.search, category, mealType, maxPreparationTime, sortBy, sortDirection, randomEnabled, onlyVege, setSearchParams, searchParams]);
  const updateFilter = (0, import_react3.useCallback)((key, value) => {
    const params = new URLSearchParams(searchParams);
    if (value) {
      params.set(key, value);
    } else {
      params.delete(key);
    }
    params.set("page", "1");
    setSearchParams(params);
  }, [searchParams, setSearchParams]);
  const resetFilters = (0, import_react3.useCallback)(() => {
    setSearch("");
    setMaxPreparationTime(null);
    setCategory("");
    setMealType("");
    setSortBy("note");
    setSortDirection("asc");
    setRandomEnabled(false);
    setOnlyVege(false);
    setSearchParams({
      sortBy: "note",
      sortDirection: "asc",
      random: "false",
      page: "1"
    });
  }, [setSearchParams]);
  const clearSearch = (0, import_react3.useCallback)(() => {
    setSearch("");
  }, []);
  const state = {
    search,
    category,
    mealType,
    maxPreparationTime,
    sortBy,
    sortDirection,
    randomEnabled,
    onlyVege
  };
  const actions = {
    setSearch,
    setCategory,
    setMealType,
    setMaxPreparationTime,
    setSortBy,
    setSortDirection,
    setRandomEnabled,
    setOnlyVege,
    clearSearch,
    resetFilters,
    updateFilter
  };
  return [state, actions];
}

// app/hooks/useRecipePagination.ts
var import_react5 = __toESM(require_react(), 1);
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/hooks/useRecipePagination.ts"
  );
  import.meta.hot.lastModified = "1743759343090.259";
}
function useRecipePagination({
  initialRecipes,
  initialPage,
  hasMore,
  searchParams
}) {
  const navigation = useNavigation();
  const moreFetcher = useFetcher();
  const [recipes, setRecipes] = (0, import_react5.useState)(initialRecipes);
  const [currentPage, setCurrentPage] = (0, import_react5.useState)(initialPage);
  const [isLoadingMore, setIsLoadingMore] = (0, import_react5.useState)(false);
  const [hasMoreRecipes, setHasMoreRecipes] = (0, import_react5.useState)(hasMore);
  const isFirstRender = (0, import_react5.useRef)(true);
  (0, import_react5.useEffect)(() => {
    if (isFirstRender.current) {
      isFirstRender.current = false;
      return;
    }
    if (navigation.state === "idle") {
      if (initialPage === 1) {
        setRecipes(initialRecipes);
      }
    }
  }, [initialRecipes, navigation.state, initialPage]);
  (0, import_react5.useEffect)(() => {
    if (navigation.state === "idle") {
      setHasMoreRecipes(hasMore);
    }
  }, [navigation.state, hasMore]);
  const loadMoreRecipes = (0, import_react5.useCallback)(() => {
    if (moreFetcher.state !== "idle" || isLoadingMore || !hasMoreRecipes) {
      return;
    }
    setIsLoadingMore(true);
    const nextPage = currentPage + 1;
    const params = new URLSearchParams(searchParams);
    params.set("page", nextPage.toString());
    moreFetcher.load(`/?index&${params.toString()}`);
  }, [currentPage, hasMoreRecipes, isLoadingMore, moreFetcher, searchParams]);
  (0, import_react5.useEffect)(() => {
    if (moreFetcher.state === "idle" && isLoadingMore && moreFetcher.data) {
      const data = moreFetcher.data;
      if (data?.pagination && "hasMore" in data.pagination) {
        setHasMoreRecipes(data.pagination.hasMore);
      }
      if (data !== void 0 && data?.recipes && Array.isArray(data.recipes) && data.recipes.length > 0) {
        setRecipes((prev) => [...prev, ...data.recipes]);
        setCurrentPage((prev) => prev + 1);
      } else {
        setHasMoreRecipes(false);
      }
      setIsLoadingMore(false);
    }
  }, [moreFetcher.state, moreFetcher.data, isLoadingMore]);
  (0, import_react5.useEffect)(() => {
    if (navigation.state === "loading" && navigation.formData) {
      setRecipes([]);
      setCurrentPage(1);
    }
  }, [navigation.state, navigation.formData]);
  return {
    currentPage,
    recipes,
    isLoading: navigation.state === "loading" || navigation.state === "submitting",
    isLoadingMore,
    hasMoreRecipes,
    loadMoreRecipes
  };
}

// app/routes/_index.tsx
var import_jsx_dev_runtime3 = __toESM(require_jsx_dev_runtime(), 1);
if (!window.$RefreshReg$ || !window.$RefreshSig$ || !window.$RefreshRuntime$) {
  console.warn("remix:hmr: React Fast Refresh only works when the Remix compiler is running in development mode.");
} else {
  prevRefreshReg = window.$RefreshReg$;
  prevRefreshSig = window.$RefreshSig$;
  window.$RefreshReg$ = (type, id) => {
    window.$RefreshRuntime$.register(type, '"app/routes/_index.tsx"' + id);
  };
  window.$RefreshSig$ = window.$RefreshRuntime$.createSignatureFunctionForTransform;
}
var prevRefreshReg;
var prevRefreshSig;
var _s = $RefreshSig$();
if (import.meta) {
  import.meta.hot = createHotContext(
    //@ts-expect-error
    "app/routes/_index.tsx"
  );
  import.meta.hot.lastModified = "1744125963483.946";
}
var meta = () => {
  return [{
    title: "Cookix"
  }, {
    name: "description",
    content: "D\xE9couvrez et filtrez toutes nos recettes pour Monsieur Cuisine Smart"
  }];
};
function RecipesIndex() {
  _s();
  const {
    recipes: initialRecipes,
    pagination,
    filters,
    appliedFilters,
    error
  } = useLoaderData();
  const [searchParams] = useSearchParams();
  const submit = useSubmit();
  const formRef = (0, import_react8.useRef)(null);
  const [filterState, filterActions] = useRecipeFilters({
    search: appliedFilters.search,
    category: appliedFilters.categoryId?.toString() || "",
    mealType: appliedFilters.mealType,
    maxPreparationTime: appliedFilters.maxPreparationTime,
    sortBy: appliedFilters.sortBy,
    sortDirection: appliedFilters.sortDirection,
    randomEnabled: appliedFilters.randomEnabled,
    onlyVege: appliedFilters.onlyVege
  });
  const {
    recipes,
    isLoading,
    isLoadingMore,
    hasMoreRecipes,
    loadMoreRecipes
  } = useRecipePagination({
    initialRecipes,
    initialPage: pagination.currentPage,
    hasMore: pagination.hasMore,
    searchParams
  });
  const [filtersVisible, setFiltersVisible] = (0, import_react8.useState)(false);
  const infiniteScrollRef = useInfiniteScroll({
    hasMore: hasMoreRecipes,
    isLoading: isLoadingMore,
    onLoadMore: loadMoreRecipes,
    enabled: !isLoading
  });
  return /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)(Layout, { children: /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("div", { className: "max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4", children: [
    /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)(SearchBar, { value: filterState.search, onChange: (e) => filterActions.setSearch(e.target.value), onClear: filterActions.clearSearch, onFilterClick: () => setFiltersVisible(true), totalRecipes: pagination.totalRecipes }, void 0, false, {
      fileName: "app/routes/_index.tsx",
      lineNumber: 242,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)(ActiveFilters, { category: filterState.category, mealType: filterState.mealType, maxPreparationTime: filterState.maxPreparationTime, categoryOptions: filters.categoryOptions, onyVegeEnabled: filters.onlyVege, onCategoryRemove: () => {
      filterActions.setCategory("");
      filterActions.updateFilter("categoryId", "");
    }, onMealTypeRemove: () => {
      filterActions.setMealType("");
      filterActions.updateFilter("mealType", "");
    }, onPrepTimeRemove: () => {
      filterActions.setMaxPreparationTime(null);
      filterActions.updateFilter("maxPreparationTime", null);
    }, onOnlyVegeRemove: () => {
      filterActions.setOnlyVege(false);
      filterActions.updateFilter("onlyVege", null);
    }, onResetAll: filterActions.resetFilters }, void 0, false, {
      fileName: "app/routes/_index.tsx",
      lineNumber: 245,
      columnNumber: 9
    }, this),
    error ? /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("div", { className: "my-8 bg-red-50 border-l-4 border-red-500 p-4 text-red-700 text-center", children: error }, void 0, false, {
      fileName: "app/routes/_index.tsx",
      lineNumber: 260,
      columnNumber: 18
    }, this) : recipes.length === 0 && !isLoading ? /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)(EmptyState, { onReset: filterActions.resetFilters }, void 0, false, {
      fileName: "app/routes/_index.tsx",
      lineNumber: 262,
      columnNumber: 57
    }, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("div", { className: "container-result grid grid-cols-1 sm:grid-cols-3 lg:grid-cols-4 gap-3", children: recipes.map((recipe, index) => /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)(BoxRecipe, { recipe }, `${recipe.id}-${index}`, false, {
      fileName: "app/routes/_index.tsx",
      lineNumber: 263,
      columnNumber: 45
    }, this)) }, void 0, false, {
      fileName: "app/routes/_index.tsx",
      lineNumber: 262,
      columnNumber: 111
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)(
      "div",
      {
        ref: infiniteScrollRef,
        className: "h-20 w-full my-4 flex justify-center items-center",
        id: "infinite-scroll-target",
        children: isLoadingMore ? /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)(LoadingIndicator, {}, void 0, false, {
          fileName: "app/routes/_index.tsx",
          lineNumber: 269,
          columnNumber: 28
        }, this) : hasMoreRecipes ? /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("div", { children: "Scroll pour plus de r\xE9sultats" }, void 0, false, {
          fileName: "app/routes/_index.tsx",
          lineNumber: 269,
          columnNumber: 68
        }, this) : /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("div", { children: "Fin des r\xE9sultats" }, void 0, false, {
          fileName: "app/routes/_index.tsx",
          lineNumber: 269,
          columnNumber: 111
        }, this)
      },
      void 0,
      false,
      {
        fileName: "app/routes/_index.tsx",
        lineNumber: 267,
        columnNumber: 9
      },
      this
    ),
    /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)(Form, { ref: formRef, method: "get", id: "filter-form", className: "hidden", children: [
      /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("input", { type: "hidden", name: "search", value: filterState.search }, void 0, false, {
        fileName: "app/routes/_index.tsx",
        lineNumber: 274,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("input", { type: "hidden", name: "categoryId", value: filterState.category }, void 0, false, {
        fileName: "app/routes/_index.tsx",
        lineNumber: 275,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("input", { type: "hidden", name: "mealType", value: filterState.mealType }, void 0, false, {
        fileName: "app/routes/_index.tsx",
        lineNumber: 276,
        columnNumber: 11
      }, this),
      filterState.maxPreparationTime && /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("input", { type: "hidden", name: "maxPreparationTime", value: filterState.maxPreparationTime.toString() }, void 0, false, {
        fileName: "app/routes/_index.tsx",
        lineNumber: 277,
        columnNumber: 46
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("input", { type: "hidden", name: "sortBy", value: filterState.sortBy }, void 0, false, {
        fileName: "app/routes/_index.tsx",
        lineNumber: 278,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("input", { type: "hidden", name: "sortDirection", value: filterState.sortDirection }, void 0, false, {
        fileName: "app/routes/_index.tsx",
        lineNumber: 279,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("input", { type: "hidden", name: "random", value: filterState.randomEnabled.toString() }, void 0, false, {
        fileName: "app/routes/_index.tsx",
        lineNumber: 280,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("input", { type: "hidden", name: "onlyVege", value: filterState.onlyVege.toString() }, void 0, false, {
        fileName: "app/routes/_index.tsx",
        lineNumber: 281,
        columnNumber: 11
      }, this),
      /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)("input", { type: "hidden", name: "page", value: "1" }, void 0, false, {
        fileName: "app/routes/_index.tsx",
        lineNumber: 282,
        columnNumber: 11
      }, this)
    ] }, void 0, true, {
      fileName: "app/routes/_index.tsx",
      lineNumber: 273,
      columnNumber: 9
    }, this),
    /* @__PURE__ */ (0, import_jsx_dev_runtime3.jsxDEV)(FilterPanel, { isVisible: filtersVisible, onClose: () => setFiltersVisible(false), filters, filterValues: {
      category: filterState.category,
      mealType: filterState.mealType,
      maxPreparationTime: filterState.maxPreparationTime,
      sortBy: filterState.sortBy,
      sortDirection: filterState.sortDirection,
      randomEnabled: filterState.randomEnabled,
      onlyVege: filterState.onlyVege
    }, onUpdateFilter: filterActions.updateFilter, onReset: filterActions.resetFilters, formRef, onSubmit: submit, setCategory: filterActions.setCategory, setMealType: filterActions.setMealType, setMaxPreparationTime: filterActions.setMaxPreparationTime, setSortBy: filterActions.setSortBy, setSortDirection: filterActions.setSortDirection, setRandomEnabled: filterActions.setRandomEnabled, setOnlyVege: filterActions.setOnlyVege }, void 0, false, {
      fileName: "app/routes/_index.tsx",
      lineNumber: 286,
      columnNumber: 9
    }, this)
  ] }, void 0, true, {
    fileName: "app/routes/_index.tsx",
    lineNumber: 240,
    columnNumber: 7
  }, this) }, void 0, false, {
    fileName: "app/routes/_index.tsx",
    lineNumber: 239,
    columnNumber: 10
  }, this);
}
_s(RecipesIndex, "Bsu15mnGhUdxsOCOUlKT1Nh7TZI=", false, function() {
  return [useLoaderData, useSearchParams, useSubmit, useRecipeFilters, useRecipePagination, useInfiniteScroll];
});
_c8 = RecipesIndex;
var _c8;
$RefreshReg$(_c8, "RecipesIndex");
window.$RefreshReg$ = prevRefreshReg;
window.$RefreshSig$ = prevRefreshSig;
export {
  RecipesIndex as default,
  meta
};
//# sourceMappingURL=/build/routes/_index-Q5VBB7IB.js.map
